# import json
import asyncio
from typing import Optional, List
from fastapi import APIRouter, Depends
from fastapi import HTTPException
from pydantic import BaseModel
from constants import JsonKeysEnum
from constants import FaissIndexMapper
from data.db_manager_gpu import VectorDBManager

router = APIRouter(
    prefix='/products',
    tags=['products']
)


class BlogModel(BaseModel):
    title: str
    content: str
    nb_comments: int
    published: Optional[bool]


class KeyParams(BaseModel):
    keywords: str
    max_length: int = 20


class EmbedParam(BaseModel):
    # file_path: str
    csv_file: str
    db_name: str
    chunk_size: Optional[int] = 1200
    clean_column: Optional[List[str]] = None


async def get_vector_db_manager():
    if not hasattr(get_vector_db_manager, 'instance'):
        get_vector_db_manager.instance = VectorDBManager()
    return get_vector_db_manager.instance


@router.post('/embed')
async def store(param: EmbedParam,
                retriever: VectorDBManager = Depends(get_vector_db_manager)) -> dict:
    try:
        index_name = retriever.faiss_files[param.db_name]
        tasks = [
            retriever.save_embeddings(csv_file=param.csv_file,
                                      db_name=param.db_name,
                                      chunk_size=param.chunk_size,
                                      columns_to_clean=param.clean_column)
        ]

        await asyncio.gather(*tasks)

        retriever.reload_index(db_name=param.db_name)
        return {'results': 'Embedding and reloading are succeeded.'}
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/retrieve')
async def retrieve(params: KeyParams,
                   retriever: VectorDBManager = Depends(get_vector_db_manager)) -> dict:
    try:
        retriever = await get_vector_db_manager()
        product_list = {}
        # proj_contents = {}
        # cases_contents = {}
        # studio_contents = {}
        # other_contents = {}
        # retriever.index_files[name]

        query_kwrds = {
            "products" : f'{params.keywords}'
        }
        # query_kwrds = {
        #     "suppbiz": f'{params.industry} {params.skillKeywords} {params.interestTopics} {params.address}',
        #     "succ_case": f'{params.industry} {params.interestTopics}',
        #     "studio": f'{params.address} {params.addressDetail}',
        #     # "elearning": f'{params.skillKeywords} {params.interestTopics}'
        # }
        tasks = [
            retriever.retrieve(db_name=name, query=query_kwrds.get("products"), k=params.max_length)
            for name, index_file in retriever.faiss_products.items()
        ]

        results = await asyncio.gather(*tasks)

        for name, result in zip(retriever.faiss_products.keys(), results):
            product_list[name] = result

        # 지원사업
        # ===========================================================================
        # tasks = [
        #     retriever.retrieve(db_name=name, query=query_kwrds.get("suppbiz"), k=params.max_length)
        #     for name, index_file in retriever.faiss_prj_files.items()
        # ]
        #
        # results = await asyncio.gather(*tasks)
        #
        # for name, result in zip(retriever.faiss_prj_files.keys(), results):
        #     proj_contents[name] = result
        #
        # supp_proj_list = proj_contents.get(FaissIndexMapper.INDEX_KEY.KEY_SUPP_PROJ.value)
        #
        # # 성공사례
        # # ===========================================================================
        # async def fetch_succ_cases(proj) -> dict:
        #     cases = {}
        #     try:
        #         query = f'{proj.get("suppProjName")}'
        #         # query = f'{proj.get("suppProjName")} {query_kwrds.get("succ_case")}'
        #         inner_tasks = [
        #             retriever.retrieve(db_name=name, query=query, k=params.max_length)
        #             for name, index_file in retriever.faiss_succcase_files.items()
        #         ]
        #         ret = await asyncio.gather(*inner_tasks)
        #
        #         for name, case in zip(retriever.faiss_succcase_files.keys(), ret):
        #             cases[name] = case
        #     except Exception as e:
        #         print(e)
        #     finally:
        #         return cases
        #
        # # 각 프로젝트에 대해 비동기적으로 succ_cases를 가져옵니다.
        # tasks = [fetch_succ_cases(proj) for proj in supp_proj_list]
        # succ_cases_results = await asyncio.gather(*tasks)
        #
        # # 결과를 원본 데이터에 추가합니다.
        # for proj, succ_cases in zip(supp_proj_list, succ_cases_results):
        #     proj['succ_case'] = succ_cases['succ_case']
        #
        # # print(f'supprot projects : {cases_contents}')
        # print('========================================')
        #
        # # 스튜디오
        # # ===========================================================================
        # tasks = [
        #     retriever.retrieve(db_name=name, query=query_kwrds.get("studio"), k=params.max_length)
        #     for name, index_file in retriever.faiss_studio_files.items()
        # ]
        #
        # results = await asyncio.gather(*tasks)
        #
        # for name, result in zip(retriever.faiss_studio_files.keys(), results):
        #     studio_contents[name] = result
        #
        # # 기타
        # # ===========================================================================
        # tasks = [
        #     retriever.retrieve(db_name=name, query=query_kwrds.get("suppbiz"), k=params.max_length)
        #     for name, index_file in retriever.faiss_other_files.items()
        # ]
        #
        # results = await asyncio.gather(*tasks)

        # for name, result in zip(retriever.faiss_other_files.keys(), results):
        #     other_contents[name] = result
        # ===========================================================================

        print("creating json")
        # Return JSON
        # archived_cases_enum = {
        #     JsonKeysEnum.SUPPORT_PROJECTS.KEY.value: proj_contents.get(FaissIndexMapper.INDEX_KEY.KEY_SUPP_PROJ.value),
        #     JsonKeysEnum.FANRO_VOD.KEY.value: other_contents.get(FaissIndexMapper.INDEX_KEY.KEY_FANROTV_VOD.value),
        #     JsonKeysEnum.STUDIO_INFO.KEY.value: studio_contents.get(FaissIndexMapper.INDEX_KEY.KEY_STUDIO_INFO.value),
        #     JsonKeysEnum.NEWS_INFO.KEY.value: other_contents.get(FaissIndexMapper.INDEX_KEY.KEY_NEWS_INFO.value),
        #     JsonKeysEnum.E_LEARNING.KEY.value: other_contents.get(FaissIndexMapper.INDEX_KEY.KEY_E_LEARN_A.value)
        # }

        archived_cases_enum = {
            JsonKeysEnum.PRODUCTS.KEY.value: product_list.get(FaissIndexMapper.INDEX_KEY.KEY_PRODUCTS.value)
        }

        # ret = embed.retrieve(db_name='open_biz', query='시니어 라이브커머스 창업지원', k=3)
        print({'results': archived_cases_enum})
        return {'results': archived_cases_enum}
    except Exception as e:
        print(e)
        return {'results': e}
