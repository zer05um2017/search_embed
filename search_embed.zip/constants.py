from enum import Enum


class Products(Enum):
    KEY = "products"

#
# class SuccessCases(Enum):
#     KEY = "succ_case"                   # 성공사례

# class FanroVod(Enum):
#     KEY = "fanro_vod"                   # 판로TV VOD
#
#
# class StudioInfo(Enum):
#     KEY = "studio_info"                 # 소담스퀘어
#
#
# class NewsInfo(Enum):
#     KEY = "news_info"                   # 소상공인 뉴스
#
#
# class ELearningClasses(Enum):
#     ALL = "level_all"                   # e러닝 전체
#     LEVEL1 = "level_1"                  # e러닝 초급
#     LEVEL2 = "level_2"                  # e러닝 중급
#     LEVEL3 = "level_3"                  # e러닝 고급
#
#
# class ELearning(Enum):
#     KEY = "e_learning"                  # e러닝


class JsonKeysEnum:
    PRODUCTS = Products
    # SUCCESS_CASES = SuccessCases
    # FANRO_VOD = FanroVod
    # STUDIO_INFO = StudioInfo
    # NEWS_INFO = NewsInfo
    # E_LEARNING = ELearning
    # CLASSES = ELearningClasses


class IndexKey(Enum):
    KEY_PRODUCTS = "products"
    # KEY_SUCC_CASE = "succ_case"
    # KEY_FANROTV_VOD = "fanrotv_vod"
    # KEY_STUDIO_INFO = "studio_info"
    # KEY_NEWS_INFO = "news_info"
    # KEY_E_LEARN_A = "e_learning_all"
    # KEY_E_LEARN1  = "e_learning_lv1"
    # KEY_E_LEARN2  = "e_learning_lv2"
    # KEY_E_LEARN3  = "e_learning_lv3"


class IndexValue(Enum):
    VALUE_PRODUCTS = "products_index"
    # VALUE_SUCC_CASE = "sc_index"
    # VALUE_FANROTV_VOD = "fv_index"
    # VALUE_STUDIO_INFO = "si_index"
    # VALUE_NEWS_INFO = "ni_index"
    # VALUE_E_LEARN_A = "el_all_index"
    # VALUE_E_LEARN1  = "el_lv1_index"
    # VALUE_E_LEARN2  = "el_lv2_index"
    # VALUE_E_LEARN3  = "el_lv3_index"


class FaissIndexMapper:
    INDEX_KEY = IndexKey
    INDEX_VALUE = IndexValue

# ============ Reference code ============
# self.index_files = {
#     "open_biz1": "ob_index1",
#     "open_biz2": "ob_index2",
#     "open_biz3": "ob_index3",
#     # "fanrotv_vod"    : "fv_index",
#     "best_prod": "bp_index",
#     "studio_info"    : "si_index",
#     "news_info"      : "ni_index",
#     "e_learning_lv1" : "el_lv1_index",
#     "e_learning_lv2" : "el_lv2_index",
#     "e_learning_lv3" : "el_lv3_index"
# }
