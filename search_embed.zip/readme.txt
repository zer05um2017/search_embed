*embedding

{
  "csv_file": "product_data",
  "db_name": "products",
  "chunk_size": 1200,
  "clean_column": [
    "name",
    "contents"
  ]
}

*retrieving

